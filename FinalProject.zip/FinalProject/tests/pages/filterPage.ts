import {by, element, ElementFinder, ElementArrayFinder} from "protractor";
import {By} from "selenium-webdriver";

export class FilterPage {

    private static RESULT_TABLE: ElementFinder = element(by.className('list'));
    private static RESULT_TABLE_CARS: By = by.className('card');
    private static BUTTON_WITH_RESULT_NUMBER: ElementFinder = element(by.id('research-btn')).element(by.tagName("span"));
    private static RESULT_TABLE_RELEASE_YEAR_GROUP: By = by.css('span.grey-text');

    public async CheckNumberOfItemsShown(): Promise<number> {
        return FilterPage.RESULT_TABLE.all(FilterPage.RESULT_TABLE_CARS).count();
    }

    public async CountNumberOfCarsShown(): Promise<string> {
        return  FilterPage.BUTTON_WITH_RESULT_NUMBER.getText();
    }


    public async CountFilteredWithCondition(): Promise<number> {
        let filterData: ElementArrayFinder =  FilterPage.RESULT_TABLE.all(FilterPage.RESULT_TABLE_RELEASE_YEAR_GROUP).filter(function(elem, index) {
                return elem.getText().then(function(text) {
                    return +(text) >= 2022;
                });
            });

        return filterData.count()
}
}