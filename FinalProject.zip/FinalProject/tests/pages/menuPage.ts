import {by, element} from "protractor";
import {Helpers} from "../helpers";

export class MenuPage {

    public async ChangeLanguage(language: string): Promise<void> {
        await Helpers.clickWithWait(element(by.linkText(language)));
    }

}