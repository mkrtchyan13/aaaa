import {by, element, ElementFinder} from "protractor";
import {Helpers} from "../helpers";

export class MainPage {
    private static BLUE_BUTTON: ElementFinder = element(by.className('waves-effect waves-light btn blue sellbtn'))
    private static MENU_ICON: ElementFinder = element(by.id('menu-icon'));
    private static FILTER_INPUT_FIELD: ElementFinder = element(by.className('select2-search__field'));
    private static FILTER_NAME: ElementFinder = element(by.className('select2-results__option select2-results__option--highlighted'));
    private static SUBMIT_FILTER_BUTTON: ElementFinder = element(by.id('search-btn'));

    public async returnButtonText(): Promise<string> {
       return  MainPage.BLUE_BUTTON.getText();
    }

    public async clickOnMenuIcon(): Promise<void> {
        await MainPage.MENU_ICON.click();
    }

    public async clickOnBrandFilter(filterName: string): Promise<void> {
        await element(by.cssContainingText('.select2-selection__rendered', filterName)).click();
    }

    public async fillInFilter(text: string): Promise<void> {
        await Helpers.waitForElementToBeVisibleThenSendKeys(MainPage.FILTER_INPUT_FIELD, text);
    }

    public async clickOnChosenFilter(): Promise<void> {
        await MainPage.FILTER_NAME.click()
    }

    public async clickOnFilterButton(): Promise<void> {
        await Helpers.clickWithWait(MainPage.SUBMIT_FILTER_BUTTON)
    }


}