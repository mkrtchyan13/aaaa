import {browser, ElementFinder, protractor} from "protractor";

export class Helpers {
    public static EC = protractor.ExpectedConditions;

    public static async clickWithWait(elem: ElementFinder, timeout: number = 3000): Promise<void> {
        let isClickable = Helpers.EC.elementToBeClickable(elem);
        await browser.wait(isClickable, timeout);
        await elem.click();
    }

    public static async waitForElementToBeVisibleThenSendKeys(elem: ElementFinder, text:string, timeout: number = 3000): Promise<void> {
        let isVisible = Helpers.EC.visibilityOf(elem);
        await browser.wait(isVisible, timeout);
        await elem.sendKeys(text)
    }
}