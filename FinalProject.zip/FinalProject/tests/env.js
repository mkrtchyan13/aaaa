/**
 * Created by aleksandr.sarichev
 */
var configure = function () {
    this.setDefaultTimeout(100 * 1000);
};
module.exports = configure;