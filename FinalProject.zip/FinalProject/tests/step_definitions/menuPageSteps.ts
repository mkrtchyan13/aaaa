import {binding, when} from "cucumber-tsflow";
import {MenuPage} from "../pages/menuPage";

@binding()
class MenuPageSteps {
    private menuPage: MenuPage = new MenuPage();

    @when(/^I change language to "([^"]*)"$/)
    public async I_change_language(language:string): Promise<void> {
        await this.menuPage.ChangeLanguage(language);
    }

}

export = MenuPageSteps;