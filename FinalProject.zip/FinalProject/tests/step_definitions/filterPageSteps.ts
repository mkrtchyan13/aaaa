import {FilterPage} from "../pages/filterPage";
import {binding, then} from "cucumber-tsflow";


const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;

@binding()
class FilterPageSteps {
    private filterByBrandPage: FilterPage = new FilterPage();

    @then(/^I make sure that filtered items count shown in blue icon in left bottom corner matches the actual count of cars shown on the page$/)
    public async I_compare_the_number_of_cars_on_button_and_shown(): Promise<void> {
        let shownNumberOfCars:number = await this.filterByBrandPage.CheckNumberOfItemsShown();
        let countedNumberOfCars:string = await this.filterByBrandPage.CountNumberOfCarsShown();
        expect(+countedNumberOfCars).to.equal(shownNumberOfCars);
    }


    @then(/^I make sure that all the cars appeared on the page meet our filtered conditions$/)
    public async I_make_sure_that_filter_by_year_works(): Promise<void> {
        let countedNumberOfCars: string = await this.filterByBrandPage.CountNumberOfCarsShown();
        let numberOfNewProducedCars:number = await this.filterByBrandPage.CountFilteredWithCondition();
        expect(numberOfNewProducedCars).to.equal(+countedNumberOfCars);
    }

}

export = FilterPageSteps;