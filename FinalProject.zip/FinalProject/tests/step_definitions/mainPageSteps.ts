import {binding, then, when} from "cucumber-tsflow";
import {browser} from "protractor";
import {MainPage} from "../pages/mainPage";

const chai = require('chai').use(require('chai-as-promised'));
const expect = chai.expect;

@binding()
class MainPageSteps {
    private mainPage: MainPage = new MainPage();

    @when(/^I open "([^"]*)" page$/)
    public async I_open_page(pageUrl: string): Promise<void> {
        await browser.get(pageUrl);
        await browser.manage().window().maximize();
    }

    @then(/^I make sure that the blue icon on the upper right corner has text "([^"]*)"$/)
    public async I_get_text_of_the_button (buttonName: string): Promise<void> {
        let actualButtonText:string = await this.mainPage.returnButtonText();
        expect(actualButtonText).to.equal(buttonName);
    }

    @when(/^I click menu bar and it opens up$/)
    public async I_open_menu(): Promise<void> {
        await this.mainPage.clickOnMenuIcon();
    }

    @when(/^I click the filter field by the "([^"]*)" name$/)
    public async I_click_on_filter_field_by_given_name(filterName: string): Promise<void> {
        await this.mainPage.clickOnBrandFilter(filterName);
    }

    @when(/^I fill in "([^"]*)"$/)
    public async I_fill_in_in_the_filter_field(text: string): Promise<void> {
        await this.mainPage.fillInFilter(text);
    }

    @when(/^I click the chosen filter$/)
    public async I_click_on_chosen_filter(): Promise<void> {
        await this.mainPage.clickOnChosenFilter()
    }

    @when(/^I click filter button$/)
    public async I_click_on_filter_button(): Promise<void> {
        await this.mainPage.clickOnFilterButton()
    }
}

export = MainPageSteps;