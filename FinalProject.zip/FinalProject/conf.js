exports.config = {
    framework: 'custom', //Type of Framework used
    frameworkPath: require.resolve('protractor-cucumber-framework'), // Framework path, if it is custom


    directConnect: true,  // How to run tests, directly on my browser or through selenium server
    seleniumAddress: 'http://localhost:4444/wd/hub', //Selenium server address to run tests, when directConnect: false
    capabilities: {
        browserName: 'chrome',
        maxInstances: 2
    },

    specs: [
        'tests/features/first-cucumber-test.feature',
    ],
    suites: {
    },


    cucumberOpts: {
        require: ['tests/step_definitions/mainPageSteps.ts', 'tests/step_definitions/menuPageSteps.ts','tests/step_definitions/filterPageSteps.ts', 'tests/env.js'],
        tags: false,
        format: 'pretty'
    },


    onPrepare() {
        require('ts-node').register({
            project: require('path').join(__dirname, './tsconfig.json') // Relative path of tsconfig.json file
        });

        browser.waitForAngularEnabled(false);
    },
};